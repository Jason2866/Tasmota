// ======================================================
// uDisplay_epd_panel.cpp - E-Paper Panel Implementation
// ======================================================

#include "uDisplay_epd_panel.h"
#include "uDisplay_SPI_controller.h"

EPDPanel::EPDPanel(const EPDPanelConfig& config,
                   SPIController* spi_ctrl,
                   uint8_t* framebuffer,
                   const uint8_t* init_cmds,
                   uint16_t init_cmds_len)
    : spi(spi_ctrl), cfg(config), fb_buffer(framebuffer),
      rotation(0), update_mode(DISPLAY_INIT_MODE), 
      display_on(true), inverted(false)
{
    // Setup backlight if pin available
    if (cfg.bpanel >= 0) {
#ifdef ESP32
        analogWrite(cfg.bpanel, 32);
#else
        pinMode(cfg.bpanel, OUTPUT);
        digitalWrite(cfg.bpanel, HIGH);
#endif
    }
    
    // Reset display if pin available
    if (cfg.reset_pin >= 0) {
        resetDisplay();
    }
    
    // Setup LUTs based on ep_mode
    setupLUTs();
    
    // Execute init commands
    if (init_cmds && init_cmds_len > 0) {
        executeInitCommands(init_cmds, init_cmds_len);
    }
}

EPDPanel::~EPDPanel() {
    // Panel doesn't own framebuffer or LUTs, so nothing to free
}

void EPDPanel::resetDisplay() {
    if (cfg.reset_pin < 0) return;
    
    pinMode(cfg.reset_pin, OUTPUT);
    digitalWrite(cfg.reset_pin, HIGH);
    delay(50);
    digitalWrite(cfg.reset_pin, LOW);
    delay(50);
    digitalWrite(cfg.reset_pin, HIGH);
    delay(200);
}

void EPDPanel::setupLUTs() {
    // Load LUTs based on ep_mode
    if (cfg.ep_mode == 1) {
        // Dual LUT mode: full and partial
        if (cfg.lut_full && cfg.lut_full_size > 0) {
            loadLUT(cfg.lut_full, cfg.lut_full_size, cfg.lut_cmd[0]);
        }
        if (cfg.lut_partial && cfg.lut_partial_size > 0) {
            loadLUT(cfg.lut_partial, cfg.lut_partial_size, cfg.lut_cmd[0]);
        }
    } else if (cfg.ep_mode == 2) {
        // Five LUT mode
        for (int i = 0; i < 5; i++) {
            if (cfg.lut_array[i] && cfg.lut_array_size[i] > 0) {
                loadLUT(cfg.lut_array[i], cfg.lut_array_size[i], cfg.lut_cmd[i]);
            }
        }
    }
    // ep_mode == 3: command-based, handled in init sequence
}

void EPDPanel::loadLUT(const uint8_t* lut_data, uint16_t lut_size, uint8_t lut_cmd) {
    if (!lut_data || lut_size == 0) return;
    
    sendCommand(lut_cmd);
    for (uint16_t i = 0; i < lut_size; i++) {
        sendData8(lut_data[i]);
    }
}

void EPDPanel::executeInitCommands(const uint8_t* cmds, uint16_t len) {
    uint16_t i = 0;
    while (i < len) {
        uint8_t cmd = cmds[i++];
        if (i >= len) break;
        
        uint8_t args = cmds[i++];
        uint8_t delay_after = 0;
        
        if (args & 0x80) {
            delay_after = args & 0x7f;
        }
        
        sendCommand(cmd);
        
        uint8_t arg_count = args & 0x1f;
        for (uint8_t j = 0; j < arg_count && i < len; j++) {
            sendData8(cmds[i++]);
        }
        
        if (delay_after) {
            delay_sync(delay_after * 10);
        }
    }
}

void EPDPanel::sendCommand(uint8_t cmd) {
    spi->beginTransaction();
    spi->csLow();
    spi->writeCommand(cmd);
    spi->csHigh();
    spi->endTransaction();
}

void EPDPanel::sendData8(uint8_t data) {
    spi->beginTransaction();
    spi->csLow();
    spi->writeData8(data);
    spi->csHigh();
    spi->endTransaction();
}

void EPDPanel::delay_sync(uint32_t ms) {
    // Wait with potential idle checking
    uint32_t start = millis();
    while (millis() - start < ms) {
        if (cfg.busy_pin >= 0 && digitalRead(cfg.busy_pin) == LOW) {
            return;  // Display went idle early
        }
        delay(10);
    }
}

// ===== UniversalPanel Interface =====

bool EPDPanel::drawPixel(int16_t x, int16_t y, uint16_t color) {
    if (!fb_buffer) return false;
    
    uint16_t byte_pos = (y * cfg.width + x) / 8;
    uint8_t bit_pos = 7 - (x % 8);
    
    if (color) {
        fb_buffer[byte_pos] |= (1 << bit_pos);
    } else {
        fb_buffer[byte_pos] &= ~(1 << bit_pos);
    }
    return true;
}

bool EPDPanel::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
    if (!fb_buffer) return false;
    
    for (int16_t yy = y; yy < y + h; yy++) {
        for (int16_t xx = x; xx < x + w; xx++) {
            drawPixel(xx, yy, color);
        }
    }
    return true;
}

bool EPDPanel::pushColors(uint16_t *data, uint16_t len, bool first) {
    // E-paper typically doesn't use pushColors directly
    return false;
}

bool EPDPanel::setAddrWindow(int16_t x0, int16_t y0, int16_t x1, int16_t y1) {
    // E-paper doesn't use address windows like LCD
    return false;
}

bool EPDPanel::drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color) {
    return fillRect(x, y, w, 1, color);
}

bool EPDPanel::drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color) {
    return fillRect(x, y, 1, h, color);
}

bool EPDPanel::displayOnff(int8_t on) {
    display_on = (on != 0);
    
    uint8_t cmd = display_on ? cfg.cmd_display_on : cfg.cmd_display_off;
    if (cmd != 0xFF) {
        sendCommand(cmd);
        return true;
    }
    return false;
}

bool EPDPanel::invertDisplay(bool invert) {
    inverted = invert;
    // Invert is typically handled in framebuffer rendering, not via command
    return false;
}

bool EPDPanel::setRotation(uint8_t rot) {
    rotation = rot & 3;
    // E-paper rotation is usually handled during update sequence
    return false;
}

bool EPDPanel::updateFrame() {
    if (!fb_buffer) return false;
    
    switch (update_mode) {
        case DISPLAY_INIT_FULL:
            updateFull();
            delay_sync(cfg.lutftime * 10);
            break;
        case DISPLAY_INIT_PARTIAL:
            updatePartial();
            delay_sync(cfg.lutptime * 10);
            break;
        default:
            return false;
    }
    
    return true;
}

void EPDPanel::updateFull() {
    // Set full memory area
    setMemoryArea(0, 0, cfg.width - 1, cfg.height - 1);
    setMemoryPointer(0, 0);
    
    // Send frame data
    sendCommand(cfg.cmd_send_data);
    uint32_t byte_count = (cfg.width * cfg.height) / 8;
    for (uint32_t i = 0; i < byte_count; i++) {
        sendData8(fb_buffer[i]);
    }
    
    // Trigger update
    triggerUpdate();
}

void EPDPanel::updatePartial() {
    // Partial update uses different memory area (if supported)
    setMemoryArea(0, 0, cfg.width - 1, cfg.height - 1);
    setMemoryPointer(0, 0);
    
    sendCommand(cfg.cmd_send_data);
    uint32_t byte_count = (cfg.width * cfg.height) / 8;
    for (uint32_t i = 0; i < byte_count; i++) {
        sendData8(fb_buffer[i]);
    }
    
    triggerUpdate();
}

void EPDPanel::triggerUpdate() {
    if (cfg.cmd_update != 0xFF) {
        sendCommand(cfg.cmd_update);
    }
    waitIdle();
}

void EPDPanel::waitIdle() {
    if (cfg.busy_pin < 0) {
        // No busy pin, just wait a fixed time
        delay_sync(100);
        return;
    }
    
    // Poll busy pin until display is idle
    uint32_t timeout = 0;
    while (timeout < 30000) {  // 30 second timeout
        if (digitalRead(cfg.busy_pin) == LOW) {
            return;  // Display is done
        }
        delay(100);
        timeout += 100;
    }
}

void EPDPanel::setMemoryArea(int x_start, int y_start, int x_end, int y_end) {
    if (cfg.cmd_set_mem_area == 0xFF) return;
    
    sendCommand(cfg.cmd_set_mem_area);
    sendData8((x_start >> 3) & 0xFF);
    sendData8((x_end >> 3) & 0xFF);
    sendData8(y_start & 0xFF);
    sendData8((y_start >> 8) & 0xFF);
    sendData8(y_end & 0xFF);
    sendData8((y_end >> 8) & 0xFF);
}

void EPDPanel::setMemoryPointer(int x, int y) {
    if (cfg.cmd_set_mem_ptr == 0xFF) return;
    
    sendCommand(cfg.cmd_set_mem_ptr);
    sendData8((x >> 3) & 0xFF);
    sendData8(y & 0xFF);
    sendData8((y >> 8) & 0xFF);
}

void EPDPanel::setUpdateMode(uint8_t mode) {
    update_mode = mode;
}

void EPDPanel::clearFrameMemory(uint8_t color) {
    if (!fb_buffer) return;
    uint32_t byte_count = (cfg.width * cfg.height) / 8;
    memset(fb_buffer, (color & 1) ? 0xFF : 0x00, byte_count);
}