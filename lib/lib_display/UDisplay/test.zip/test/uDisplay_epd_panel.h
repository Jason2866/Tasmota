// ======================================================
// uDisplay_epd_panel.h - E-Paper Panel Implementation
// ======================================================

#pragma once

#include "uDisplay_panel.h"

class SPIController;

/**
 * E-Paper specific config
 * Handles LUT (Look-Up Table) and partial/full update modes
 */
struct EPDPanelConfig {
    // ===== Base Display Config =====
    uint16_t width;
    uint16_t height;
    uint8_t bpp;              // Always 1 for e-paper
    uint8_t col_mode;
    
    // ===== Display Control Commands =====
    uint8_t cmd_display_on;
    uint8_t cmd_display_off;
    uint8_t cmd_invert_on;
    uint8_t cmd_invert_off;
    uint8_t cmd_memory_access;
    uint8_t cmd_startline;
    
    // ===== Per-Rotation Configuration =====
    uint8_t rot_cmd[4];
    uint16_t x_addr_offset[4];
    uint16_t y_addr_offset[4];
    uint8_t address_mode;
    bool all_commands_mode;
    
    // ===== Reset & Power Control =====
    int8_t reset_pin;
    int8_t busy_pin;
    int8_t bpanel;
    
    // ===== LUT Configuration =====
    uint8_t ep_mode;           // 1=dual-LUT, 2=five-LUT, 3=cmd-based
    uint8_t* lut_full;         // Full update lookup table
    uint16_t lut_full_size;
    uint8_t* lut_partial;      // Partial update lookup table
    uint16_t lut_partial_size;
    uint8_t* lut_array[5];     // For 5-LUT mode
    uint16_t lut_array_size[5];
    uint8_t lut_cmd[5];        // Commands to load each LUT
    
    // ===== Update Control =====
    uint16_t lutftime;         // Full update time (ms * 10)
    uint16_t lutptime;         // Partial update time (ms * 10)
    uint16_t lut3time;         // Misc timing
    
    // ===== Memory Addressing =====
    uint8_t cmd_set_mem_area;
    uint8_t cmd_set_mem_ptr;
    uint8_t cmd_send_data;
    uint8_t cmd_clr_frame;
    uint8_t cmd_send_frame;
    uint8_t cmd_lut;
    
    // ===== Display-specific Commands =====
    uint8_t cmd_update;        // Trigger update command
};

// EPD Update Mode Constants
#define DISPLAY_INIT_MODE 0
#define DISPLAY_INIT_PARTIAL 1
#define DISPLAY_INIT_FULL 2

class EPDPanel : public UniversalPanel {
public:
    /**
     * Constructor - receives framebuffer from uDisplay
     * Executes init commands only
     */
    EPDPanel(const EPDPanelConfig& config,
             SPIController* spi_ctrl,
             uint8_t* framebuffer,
             const uint8_t* init_cmds = nullptr,
             uint16_t init_cmds_len = 0);
    
    ~EPDPanel();
    
    // ===== UniversalPanel Interface (return true=handled, false=fall back) =====
    bool drawPixel(int16_t x, int16_t y, uint16_t color) override;
    bool fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) override;
    bool pushColors(uint16_t *data, uint16_t len, bool first = false) override;
    bool setAddrWindow(int16_t x0, int16_t y0, int16_t x1, int16_t y1) override;
    bool drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color) override;
    bool drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color) override;
    
    bool displayOnff(int8_t on) override;
    bool invertDisplay(bool invert) override;
    bool setRotation(uint8_t rotation) override;
    bool updateFrame() override;
    
    // ===== EPD-Specific Control =====
    void setUpdateMode(uint8_t mode);
    void clearFrameMemory(uint8_t color = 0xFF);

private:
    // ===== Hardware & Configuration =====
    SPIController* spi;
    EPDPanelConfig cfg;
    
    // ===== Framebuffer =====
    uint8_t* fb_buffer;
    
    // ===== EPD State =====
    uint8_t rotation;
    uint8_t update_mode;
    bool display_on;
    bool inverted;
    
    // ===== LUT Management =====
    void loadLUT(const uint8_t* lut_data, uint16_t lut_size, uint8_t lut_cmd);
    void setupLUTs();
    
    // ===== Memory & Update Addressing =====
    void setMemoryArea(int x_start, int y_start, int x_end, int y_end);
    void setMemoryPointer(int x, int y);
    
    // ===== Update Sequences =====
    void updateFull();
    void updatePartial();
    void triggerUpdate();
    void waitIdle();
    
    // ===== Display Control =====
    void sendCommand(uint8_t cmd);
    void sendData8(uint8_t data);
    void executeInitCommands(const uint8_t* cmds, uint16_t len);
    void resetDisplay();
    void delay_sync(uint32_t ms);
};