// ======================================================
// uDisplay_spi_panel.cpp - SPI LCD Panel Implementation
// ======================================================

#include "uDisplay_spi_panel.h"
#include "uDisplay_SPI_controller.h"

SPIPanel::SPIPanel(const SPIPanelConfig& config,
                   SPIController* spi_ctrl,
                   uint8_t* framebuffer,
                   const uint8_t* init_cmds,
                   uint16_t init_cmds_len)
    : spi(spi_ctrl), cfg(config), fb_buffer(framebuffer), 
      rotation(0), display_on(true), inverted(false)
{
    // Initialize address window state
    current_x0 = 0;
    current_y0 = 0;
    current_x1 = cfg.width - 1;
    current_y1 = cfg.height - 1;
    
    // Setup backlight if pin available
    if (cfg.bpanel >= 0) {
#ifdef ESP32
        analogWrite(cfg.bpanel, 32);
#else
        pinMode(cfg.bpanel, OUTPUT);
        digitalWrite(cfg.bpanel, HIGH);
#endif
    }
    
    // Reset display if pin available
    if (cfg.reset_pin >= 0) {
        resetDisplay();
    }
    
    // Execute init commands if provided
    if (init_cmds && init_cmds_len > 0) {
        executeInitCommands(init_cmds, init_cmds_len);
    }
}

SPIPanel::~SPIPanel() {
    // Panel doesn't own framebuffer, so nothing to free
}

void SPIPanel::resetDisplay() {
    if (cfg.reset_pin < 0) return;
    
    pinMode(cfg.reset_pin, OUTPUT);
    digitalWrite(cfg.reset_pin, HIGH);
    delay(50);
    digitalWrite(cfg.reset_pin, LOW);
    delay(50);
    digitalWrite(cfg.reset_pin, HIGH);
    delay(200);
}

void SPIPanel::executeInitCommands(const uint8_t* cmds, uint16_t len) {
    uint16_t i = 0;
    while (i < len) {
        uint8_t cmd = cmds[i++];
        if (i >= len) break;
        
        uint8_t args = cmds[i++];
        uint8_t delay_after = 0;
        
        // Check if delay flag is set (bit 7)
        if (args & 0x80) {
            delay_after = args & 0x7f;
        }
        
        // Send command
        sendCommand(cmd);
        
        // Send arguments
        uint8_t arg_count = args & 0x1f;
        for (uint8_t j = 0; j < arg_count && i < len; j++) {
            sendData8(cmds[i++]);
        }
        
        // Handle delay if needed
        if (delay_after) {
            delay(delay_after * 10);
        }
    }
}

void SPIPanel::sendCommand(uint8_t cmd) {
    spi->beginTransaction();
    spi->csLow();
    spi->writeCommand(cmd);
    spi->csHigh();
    spi->endTransaction();
}

void SPIPanel::sendData8(uint8_t data) {
    if (!cfg.all_commands_mode) {
        spi->beginTransaction();
        spi->csLow();
        spi->writeData8(data);
        spi->csHigh();
        spi->endTransaction();
    } else {
        sendCommand(data);
    }
}

void SPIPanel::sendData16(uint16_t data) {
    spi->beginTransaction();
    spi->csLow();
    spi->writeData16(data);
    spi->csHigh();
    spi->endTransaction();
}

// ===== UniversalPanel Interface Implementation =====

bool SPIPanel::drawPixel(int16_t x, int16_t y, uint16_t color) {
    if (!fb_buffer || cfg.bpp >= 16) {
        return false;  // Fall back to uDisplay default
    }
    
    // For monochrome (bpp=1)
    if (cfg.bpp == 1) {
        uint16_t byte_pos = (y * cfg.width + x) / 8;
        uint8_t bit_pos = 7 - (x % 8);
        
        if (color) {
            fb_buffer[byte_pos] |= (1 << bit_pos);
        } else {
            fb_buffer[byte_pos] &= ~(1 << bit_pos);
        }
        return true;
    }
    
    return false;
}

bool SPIPanel::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
    if (!fb_buffer || cfg.bpp >= 16) {
        return false;
    }
    
    for (int16_t yy = y; yy < y + h; yy++) {
        for (int16_t xx = x; xx < x + w; xx++) {
            drawPixel(xx, yy, color);
        }
    }
    return true;
}

bool SPIPanel::pushColors(uint16_t *data, uint16_t len, bool first) {
    if (cfg.bpp >= 16) {
        // Can handle 16-bit direct streaming
        setAddrWindow_internal(current_x0, current_y0, current_x1, current_y1);
        sendCommand(cfg.cmd_write_ram);
        
        for (uint16_t i = 0; i < len; i++) {
            sendData16(data[i]);
        }
        return true;
    }
    return false;
}

bool SPIPanel::setAddrWindow(int16_t x0, int16_t y0, int16_t x1, int16_t y1) {
    setAddrWindow_internal(x0, y0, x1, y1);
    return true;
}

void SPIPanel::setAddrWindow_internal(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    current_x0 = x0;
    current_y0 = y0;
    current_x1 = x1;
    current_y1 = y1;
    
    sendAddrWindow(x0, y0, x1, y1);
}

void SPIPanel::sendAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    // Apply rotation offsets
    x0 += cfg.x_addr_offset[rotation];
    x1 += cfg.x_addr_offset[rotation];
    y0 += cfg.y_addr_offset[rotation];
    y1 += cfg.y_addr_offset[rotation];
    
    // Send X address window
    sendCommand(cfg.cmd_set_addr_x);
    sendData8((x0 >> 8) & 0xFF);
    sendData8(x0 & 0xFF);
    sendData8((x1 >> 8) & 0xFF);
    sendData8(x1 & 0xFF);
    
    // Send Y address window
    sendCommand(cfg.cmd_set_addr_y);
    sendData8((y0 >> 8) & 0xFF);
    sendData8(y0 & 0xFF);
    sendData8((y1 >> 8) & 0xFF);
    sendData8(y1 & 0xFF);
}

bool SPIPanel::drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color) {
    return fillRect(x, y, w, 1, color);
}

bool SPIPanel::drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color) {
    return fillRect(x, y, 1, h, color);
}

bool SPIPanel::displayOnff(int8_t on) {
    display_on = (on != 0);
    
    uint8_t cmd = display_on ? cfg.cmd_display_on : cfg.cmd_display_off;
    if (cmd != 0xFF) {
        sendCommand(cmd);
        return true;
    }
    return false;
}

bool SPIPanel::invertDisplay(bool invert) {
    inverted = invert;
    
    uint8_t cmd = invert ? cfg.cmd_invert_on : cfg.cmd_invert_off;
    if (cmd != 0xFF) {
        sendCommand(cmd);
        return true;
    }
    return false;
}

bool SPIPanel::setRotation(uint8_t rot) {
    rotation = rot & 3;
    
    // Send rotation command if available
    if (cfg.rot_cmd[rotation] != 0xFF) {
        sendCommand(cfg.cmd_memory_access);
        sendData8(cfg.rot_cmd[rotation]);
        return true;
    }
    return false;
}

bool SPIPanel::updateFrame() {
    // For buffered displays, flush framebuffer to display
    if (!fb_buffer) return false;
    
    // Set full window
    setAddrWindow_internal(0, 0, cfg.width - 1, cfg.height - 1);
    sendCommand(cfg.cmd_write_ram);
    
    // Send all framebuffer data
    // Assume fb_buffer is sized correctly by uDisplay
    if (cfg.bpp == 1) {
        uint32_t byte_count = (cfg.width * cfg.height) / 8;
        for (uint32_t i = 0; i < byte_count; i++) {
            sendData8(fb_buffer[i]);
        }
    }
    
    return true;
}