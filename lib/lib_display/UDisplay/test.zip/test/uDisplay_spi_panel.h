// ======================================================
// uDisplay_spi_panel.h - SPI LCD Panel Implementation
// ======================================================

#pragma once

#include "uDisplay_panel.h"

class SPIController;

/**
 * Stack-allocated configuration for SPI-based displays
 * Passed to SPIPanel constructor after parsing
 * 
 * NAMING DECODED:
 * - cmd_set_addr_x was saw_1 (Set Address Window X command)
 * - cmd_set_addr_y was saw_2 (Set Address Window Y command) 
 * - cmd_write_ram was saw_3 (Write to RAM command)
 * - cmd_memory_access was madctrl (rotation control)
 * - address_mode was sa_mode (8/16/32-bit addressing)
 */
struct SPIPanelConfig {
    // ===== Display Dimensions =====
    uint16_t width;
    uint16_t height;
    uint8_t bpp;              // bits per pixel (1, 8, 16, etc.)
    uint8_t col_mode;         // pixel addressing: 8, 16, or 32-bit
    
    // ===== Address Window Protocol =====
    uint8_t cmd_set_addr_x;   // Command to set X address range
    uint8_t cmd_set_addr_y;   // Command to set Y address range
    uint8_t cmd_write_ram;    // Command to write pixel data
    
    // ===== Display Control Commands =====
    uint8_t cmd_display_on;
    uint8_t cmd_display_off;
    uint8_t cmd_invert_on;
    uint8_t cmd_invert_off;
    uint8_t cmd_memory_access; // For rotation settings
    uint8_t cmd_startline;     // For vertical scroll offset
    
    // ===== Per-Rotation Configuration =====
    uint8_t rot_cmd[4];        // Memory access command variant for each rotation
    uint16_t x_addr_offset[4]; // Address offset per rotation
    uint16_t y_addr_offset[4];
    uint8_t address_mode;      // Addressing scheme
    
    // ===== Flags =====
    bool all_commands_mode;    // If true: send data bytes as commands
    
    // ===== Reset & Power Control =====
    int8_t reset_pin;          // GPIO for display reset (-1 if none)
    int8_t busy_pin;           // GPIO for busy signal (-1 if none)
    int8_t bpanel;             // Backlight GPIO (-1 if none)
};

class SPIPanel : public UniversalPanel {
public:
    /**
     * Constructor - receives framebuffer from uDisplay if needed
     * Executes init commands only
     */
    SPIPanel(const SPIPanelConfig& config,
             SPIController* spi_ctrl,
             uint8_t* framebuffer,
             const uint8_t* init_cmds = nullptr,
             uint16_t init_cmds_len = 0);
    
    ~SPIPanel();
    
    // ===== UniversalPanel Interface (return true=handled, false=fall back) =====
    bool drawPixel(int16_t x, int16_t y, uint16_t color) override;
    bool fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) override;
    bool pushColors(uint16_t *data, uint16_t len, bool first = false) override;
    bool setAddrWindow(int16_t x0, int16_t y0, int16_t x1, int16_t y1) override;
    bool drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color) override;
    bool drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color) override;
    
    bool displayOnff(int8_t on) override;
    bool invertDisplay(bool invert) override;
    bool setRotation(uint8_t rotation) override;
    bool updateFrame() override;

private:
    // ===== Hardware & Configuration =====
    SPIController* spi;            // Not owned by panel
    SPIPanelConfig cfg;            // Copy of config
    
    // ===== Framebuffer =====
    uint8_t* fb_buffer;            // Framebuffer (if provided by uDisplay, NULL otherwise)
    
    // ===== Display State =====
    uint8_t rotation;              // Current rotation (0-3)
    uint16_t current_x0, current_y0, current_x1, current_y1;
    bool display_on;
    bool inverted;
    
    // ===== Internal Helpers =====
    void setAddrWindow_internal(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
    void sendAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
    void sendCommand(uint8_t cmd);
    void sendData8(uint8_t data);
    void sendData16(uint16_t data);
    void executeInitCommands(const uint8_t* cmds, uint16_t len);
    void resetDisplay();
};